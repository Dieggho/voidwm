#!/bin/sh
/home/void/.fehbg &
xcompmgr &
slstatus &